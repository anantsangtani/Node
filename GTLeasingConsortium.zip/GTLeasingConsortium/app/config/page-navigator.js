define(['app'], function (app) {
    'use strict';
    return app.config(function ($stateProvider, $locationProvider, $urlRouterProvider) {
        $stateProvider.state('baseLayoutState', {
            'abstract': true,
            url: '',
            templateUrl: 'app/partials/layout/homeLayout.html'
        });
        $stateProvider.state('defaultPageState', {
            'abstract': true,
            url: '/GTLeasingConsortium',
            parent: 'baseLayoutState',
            views: {
                'north': {
                    templateUrl: 'app/partials/layout/header.html',
                },
                'menu': {

                },
                'south': {
                    templateUrl: 'app/partials/layout/footer.html'
                }
            }
        });
        $stateProvider.state('defaultPageStateForHome', {
            'abstract': true,
            url: '/GTLeasingConsortium',
            parent: 'baseLayoutState',
            views: {
                'north': {
                    template: ' ',
                },
                'menu': {

                },
                'south': {
                    templateUrl: 'app/partials/layout/footer.html'
                }
            }
        });
        $stateProvider.state('home', {
            url: '/home',
            parent: 'defaultPageStateForHome',
            views: {
                'center@baseLayoutState': {
                    templateUrl: 'app/partials/modules/login.html',
                    controller: 'HomeController as homeController'
                } 
            }
        });
        $stateProvider.state('contract-management', {
            url: '/contract-management',
            parent: 'defaultPageState',
            views: {
                'menu@baseLayoutState': {
                    templateUrl : 'app/partials/layout/menu.html',
                    controller: 'MenuController as menuController'
                },
                'center@baseLayoutState': {
                    templateUrl: 'app/partials/modules/contract-management.html',
                    controller: 'ContractManagementController as vm'
                },   
            },params: {
                notification : null
            } 
        });
       
         

                   
      
        $locationProvider.html5Mode(false);
        $urlRouterProvider.otherwise('/GTLeasingConsortium/home');
        $urlRouterProvider.when('', '/GTLeasingConsortium');
    });
});
