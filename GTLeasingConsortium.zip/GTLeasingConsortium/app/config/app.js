define(['angular', 'angular-route', 'angular-route-css', 'ui-bootstrap-tpls', 'angular-file-upload', 'loading-bar', 'bootstrap-datetimepicker', 'dropdown-multiselect', 'pagination',
  'angular-sanitize', 'angular-scrollpoint', 'angular-draggable', 'app-shared/module-loader', 'app-module/module-loader', 'ng-tags-input', 'restangular', 'ui-grid', 'angular-material', 'ng-fileupload','angular-material-upload','md-data-table','angular-md5','fusioncharts','angular-fusioncharts','fusioncharts-theme-fint','angular-material-icons','moment','angular-moment','angular-messages'], function (angular) {
    'use strict';
    var _module = angular.module('GTLeasingConsortium', ['app.shared', 'app.module', 'ui.router', 'uiRouterStyles',
   'ui.bootstrap', 'angularFileUpload', 'angular-loading-bar', 'ngSanitize', 'angularjs-dropdown-multiselect', 'angularUtils.directives.dirPagination', 'ui.scrollpoint', 'ngDraggable', 'ngTagsInput', 'restangular', 'ui.grid', 'ui.grid.edit', 'ui.grid.pagination', 'ngMaterial', 'ngFileUpload','lfNgMdFileInput','md.data.table','angular-md5','ng-fusioncharts','ngMdIcons','angularMoment','ngMessages']);

    //Apply theme with different color :  red, pink, purple, deep-purple, indigo, blue, light-blue, cyan, teal, green, light-green, lime, yellow, amber, orange, deep-orange, brown, grey, blue-grey
    
       /*_module.config(function($mdThemingProvider){
         $mdThemingProvider.theme('default')            .primaryPalette('pink')
            .accentPalette('pink');
        $mdThemingProvider.alwaysWatchTheme(true);
    });*/
    _module.config(function ($mdThemingProvider) {
		$mdThemingProvider.definePalette('amazingPaletteName', {
		  '50': 'rgb(13,71,161)',
			'100': 'rgb(79, 45, 127)',
			'200': 'rgb(79, 45, 127)',
			'300': 'rgb(79, 45, 127)',
			'400': 'rgb(79, 45, 127)',
			'500': 'rgb(79, 45, 127)',
			'600': 'rgb(79, 45, 127)',
			'700': 'rgb(79, 45, 127)',
			'800': 'rgb(79, 45, 127)',
			'900': 'rgb(79, 45, 127)',
			'A100': 'rgb(79, 45, 127)',
			'A200': 'rgb(79, 45, 127)',
			'A400': 'rgb(79, 45, 127)',
			'A700': 'rgb(79, 45, 127)',
				
			'contrastDefaultColor': 'light', // whether, by default, text (contrast)
			// on this palette should be dark or light

			'contrastDarkColors': ['50', '100', //hues which contrast should be 'dark' by default
             '200', '300', '400', 'A100'],
			'contrastLightColors': undefined // could also specify this if default was 'dark'
		});
		$mdThemingProvider.theme('default')
			.primaryPalette('amazingPaletteName')
			.accentPalette('amazingPaletteName');
		$mdThemingProvider.alwaysWatchTheme(true);
	});
    
    
    
    

    _module.run(['$rootScope',function ($rootScope) {
        $rootScope.XHRService = false;
        //$rootScope.selectedIndex = (window.sessionStorage.selectedIndex === undefined)? 0 : window.sessionStorage.selectedIndex;
	}]);
    _module.config(function($provide) {
        $provide.decorator('$state', function($delegate, $stateParams) {
            $delegate.forceReload = function() {
                return $delegate.go($delegate.current, $stateParams, {
                    reload: true,
                    inherit: false,
                    notify: true
                });
            };
            return $delegate;
        });
    });
	_module.config(function (RestangularProvider, appConstants, $provide, $httpProvider) {
		var newBaseUrl = appConstants().BASE_URL;
		RestangularProvider.setBaseUrl(newBaseUrl);

		$provide.decorator('$state', function ($delegate, $stateParams) {
			$delegate.forceReload = function () {
				return $delegate.go($delegate.current, $stateParams, {
					reload: true,
					inherit: false,
					notify: true
				});
			};
			return $delegate;
		});

		RestangularProvider.addResponseInterceptor(function (data, operation, what, url, response, deferred) {
			var extractedData;
			if (operation === "getList") {
				if (data.objectList == null || data.objectList == undefined) {
					extractedData = data;
				} else {
					extractedData = data.objectList;
				}
			} else {
				extractedData = data;
			}
			return extractedData;
		});

		RestangularProvider.setDefaultHeaders({
			'Content-Type': 'application/json; charset=UTF-8'
		});
	});
    _module.filter('commaSeparatedNamesFilter', function() {

    return function(inputArray) {
        var arr = inputArray,
        outputArray = [];
        arr.forEach(function(d,i){
            outputArray.push(d.name);
        });
        return outputArray.join(", ");
    }
});
    


_module.filter('activatedTokenOnlyFilter', function() {
    
    return function(inputArray) {
        var output = [];
        inputArray.forEach((d,i)=>{
            if(d.toggle == true){
                output.push(d);
            }
        });
        return output;
    }
});
    _module.directive('mdDatepickerAutoopen', function ($timeout) {
      return {
        restrict: 'A',
        require: 'mdDatepicker',
        link: function (scope, element, attributes, DatePickerCtrl) {
          element.find('input').parent().on('click', function (e) {
            $timeout(DatePickerCtrl.openCalendarPane.bind(DatePickerCtrl, e));
          });
        }
      };
    });
    return _module;
});
