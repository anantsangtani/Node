// For any third party dependencies, like jQuery, place them in the lib folder.

requirejs
    .config({
        baseUrl: './',
        waitSeconds: 300,
        paths: {
            'app': 'app/config/app',
            'start': 'app/config/start',
            'app-shared': 'app/util/',
            'app-module': 'app/module',
            'routes': 'app/config/page-navigator',
            'domReady': 'lib/requireJs/domReady',
            'jquery': 'lib/jQuery/jquery-1.11.2',
            'angular': 'lib/angularjs/angular',
            'md-data-table': 'lib/angularjs/module/material/datatable/md-data-table',
            'angular-route': 'lib/angularjs/module/route/angular-ui-router',
            'angular-route-css': 'lib/angularjs/module/route/ui-router-styles',
            'angular-file-upload': 'lib/angularjs/module/file/angular-file-upload',
            'loading-bar': 'lib/angularjs/module/loadingbar/loading-bar',
            'angular-sanitize': 'lib/angularjs/module/sanitize/angular-sanitize',
            'bootstrap': 'lib/bootstrap/bootstrap',
            'ui-bootstrap-tpls': 'lib/bootstrap/ui-bootstrap-tpls',
            'jquery.fileDownload': 'lib/jQuery/module/filedownload/jquery.fileDownload',
            'jquery.ui': 'lib/jQuery/module/ui/jquery-ui',
            'moment': 'lib/moment/moment.min',
            'angular-moment': 'lib/moment/angular-moment.min',
            'bootstrap-datetimepicker': 'lib/bootstrap/module/bootstrap-datetimepicker',
            'dropdown-multiselect': 'lib/angularjs/module/multiselect/angularjs-dropdown-multiselect',
            'lodash': 'lib/lodash/lodash.min',
            'pagination': 'lib/angularjs/module/pagination/dirPagination',
            'summernote': 'lib/angularjs/module/texteditor/summernote',
            'angular-summernote': 'lib/angularjs/module/texteditor/angular-summernote',
            'angular-draggable': 'lib/angularjs/module/draggable/ngDraggable',
            'angular-scrollpoint': 'lib/angularjs/module/scrollpoint/scrollpoint',
            'angular-wizard': 'lib/angularjs/module/wizard/angular-wizard',
            'ng-tags-input': 'lib/angularjs/module/wordtag/ng-tags-input',
            'angular-aria': 'lib/angularjs/module/aria/angular-aria',
            'angular-animate': 'lib/angularjs/module/animate/angular-animate',
            'angular-messages': 'lib/angularjs/module/messages/angular-messages',
            'angular-material': 'lib/angularjs/module/material/angular-material',
            'restangular': 'lib/restangular/restangular',
            'underscore': 'lib/underscore/underscore',
            'ui-grid': 'lib/ui-grid/ui-grid',
            'table-edit': 'lib/jQuery/module/table-edit/jquery.tabledit',
            'ng-fileupload': 'lib/ng-file-upload/ng-file-upload',
            'ng-fileupload-shim': 'lib/ng-file-upload/ng-file-upload-shim',
            'angular-material-upload' : 'lib/angularjs/module/material/file-upload/lf-ng-md-file-input',
            'angular-md5' : 'lib/angular-md5/angular-md5.min',
            'fusioncharts' : 'lib/angularjs/module/fusioncharts/fusioncharts',
            'angular-fusioncharts' : 'lib/angularjs/module/fusioncharts/angular-fusioncharts.min',
            'fusioncharts-theme-fint' : 'lib/angularjs/module/fusioncharts/themes/fusioncharts.theme.fint',
            'angular-material-icons':'lib/angularjs/module/material/angular-material-icons.min'
        },
        shim: {
            'angular': {
                exports: 'angular',
                deps: ['jquery']
            },
            'jquery': {
                exports: "jquery"
            },
            'jquery.ui': {
                exports: "jquery.ui",
                deps: ['jquery']
            },
            'class.mutators': {
                deps: ['jquery', 'mootools'],
                exports: 'classmutators'
            },
            'angular-route': {
                deps: ['angular']
            },
            'angular-route-css': {
                deps: ['angular']
            },
            'angular-file-upload': {
                deps: ['angular']
            },
            'loading-bar': {
                deps: ['angular']
            },
            'angular-sanitize': {
                deps: ['angular']
            },
            'bootstrap': {
                deps: ['jquery', 'jquery.ui']
            },
            'ui-bootstrap-tpls': {
                deps: ['angular', 'bootstrap']
            },
            'jqcloud': {
                deps: ['bootstrap']
            },
            'jquery.fileDownload': {
                deps: ['jquery']
            },
            'moment': {
                exports: "moment",
                deps: ['jquery']
            },
            'angular-moment': {
                exports: "angular-moment",
                deps: ['jquery','moment']
            },
            'bootstrap-datetimepicker': {
                deps: ['moment', 'jquery', 'bootstrap']
            },
            'lodash': {
                exports: "lodash"
            },
            'dropdown-multiselect': {
                deps: ['lodash', 'angular']
            },
            'pagination': {
                deps: ['angular']
            },
            'summernote': {
                deps: ['jquery', 'bootstrap']
            },
            'angular-summernote': {
                deps: ['summernote', 'angular']
            },
            'angular-scrollpoint': {
                deps: ['angular']
            },
            'angular-draggable': {
                deps: ['angular']
            },
            'angular-wizard': {
                deps: ['angular']
            },
            'ng-tags-input': {
                deps: ['angular']
            },
            'angular-aria': {
                deps: ['angular']
            },
            'angular-animate': {
                deps: ['angular']
            },
            'angular-messages': {
                deps: ['angular']
            },
            'angular-material': {
                deps: ['angular', 'angular-aria', 'angular-animate', 'angular-messages']
            },
            'angular-material-upload' :{
                    deps : [  'angular','angular-material','angular-aria','angular-animate','angular-messages']
             },
            'underscore': {
                exports: "underscore",
                deps: ['angular']
            },
            'restangular': {
                exports: "restangular",
                deps: ['underscore', 'angular']
            },
            'ui-grid': {
                exports: "ui-grid",
                deps: ['angular']
            },
            'table-edit': {
                deps: ['jquery']
            },
            'ng-fileupload': {

                deps: ['angular']
            },
            'md-data-table': {
                deps: ['angular', 'angular-aria', 'angular-animate', 'angular-messages', 'angular-material']
            },
            'angular-md5' : {
                exports : "md5",
                deps : [ 'angular']
            },
            'fusioncharts' : {
                exports : "fusioncharts",
                deps : [ 'angular']
            },
            'angular-fusioncharts' : {
                exports : "angular-fusioncharts",
                deps : [ 'angular','fusioncharts']
            },
            'fusioncharts-theme-fint' : {
                exports : "fusioncharts-theme-fint",
                deps : [ 'angular','fusioncharts']
            },
            'angular-material-icons': {
                exports: 'angular-material-icons',
                deps: ['angular','angular-material']
            }
        },

        deps: ['start']
    });
