define([ '../common-module' ], function(directives) {
	directives.directive('sdAlert', function(AlertService) {
		return {
			restrict: 'E',
			templateUrl: 'app/util/template/sdAlertTemplate.html',
			scope: {
				databaseMessage: "@databaseMessage",
				inputDetailMessage: "@detailMessage",
				inputHeader: "@header",
				alertModel: "="
			},
			link: function($scope, element, attrs) {
				$scope.visible=false;
				
				$scope.alert = $scope.alertModel || {};
				
				
				var isAlertType=false;
				var success=null;
				var warning=null;
				var error=null;
				var info=null;
				
				$scope.closable=null;
				
				$scope.alert.showAlert = function(){
					$scope.visible=true;
					setAlertDetails();
				};
				
				
				$scope.alert.hideAlert = function(){
					$scope.visible=false;
				};
				
				var setAlertDetails = function(){
					$scope.alertClass="alert";
					if($scope.inputDetailMessage==null && $scope.inputHeader==null){
						var _message = AlertService.getMessage();
						$scope.detailMessageAlert=_message.detailMessage;
						$scope.databaseMessageAlert=_message.databaseMessage;
						$scope.headerAlert=_message.header;
						success=_message.success;
						warning=_message.warning;
						error=_message.error;
						info=_message.info;
						$scope.closable=AlertService.getClosable();
						
					}else{
						$scope.detailMessageAlert=$scope.inputDetailMessage;
						$scope.databaseMessageAlert=$scope.databaseMessage;
						$scope.headerAlert=$scope.inputHeader;
						success=$scope.$eval(attrs.success);
						warning=$scope.$eval(attrs.warning);
						error=$scope.$eval(attrs.error);
						info=$scope.$eval(attrs.info);
						$scope.closable=$scope.$eval(attrs.closable);
					}
					
					if($scope.closable==null){
						$scope.closable=true;
					}
					
					if($scope.closable){
						$scope.alertClass=$scope.alertClass+" alert-dismissible";
					}
					
					
					if(success){
						$scope.alertClass=$scope.alertClass+" alert-success";
						isAlertType=true;
					}
					if(warning){
						$scope.alertClass=$scope.alertClass+" alert-warning";
						isAlertType=true;
					}
					if(error){
						$scope.alertClass=$scope.alertClass+" alert-danger";
						isAlertType=true;
					}
					if(info){
						$scope.alertClass=$scope.alertClass+" alert-info";
						isAlertType=true;
					}
					
					if(!isAlertType){
						$scope.alertClass=$scope.alertClass+" alert-info";
					}
				};
				
				
			}
			
		};
	});

});

 