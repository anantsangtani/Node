define([ '../common-module' ], function(serviceModule) {
	serviceModule.service('EthereumService', function() {
        var stringArray = [];
        var getStringArrayFromResponse =  function(result){
            stringArray = [];
            if(result && result.response && result.response.length > 0){
                for(i = 0; i < result.response.length; i++)
                {
                   var tempVar = '';
                   try
                   {
                      tempVar = web3.toAscii(result.response[i]).replace(/[^a-z0-9:@.-]/gi,'');
                   }
                   catch(err)
                   {
                      tempVar = '0x'+result.response[i].substring(26);
                   }
                   stringArray.push(tempVar);
                }
            }
            return stringArray;
        };
        var getJSONArrayFromStringArray = function(attributeList,stringArray){
            var jsonArray = [];
            if(stringArray && attributeList && stringArray.length >0 && attributeList.length>0){
                var j = 0;
                while(j < stringArray.length){
                       var  object = {};
                       for(var i in attributeList){
                            object[attributeList[i]] = stringArray[j++];
                       }
                       if(stringArray[j++] == ':')
                       {
                         jsonArray.push(object);
                         object = {};
                       }
                }
            }
            return jsonArray;
        };
        return {
            getStringArrayFromResponse : getStringArrayFromResponse,
            getJSONArrayFromStringArray : getJSONArrayFromStringArray
        };
	});
});