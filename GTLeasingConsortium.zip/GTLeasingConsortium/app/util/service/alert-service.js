define([ '../common-module' ], function(serviceModule) {
	serviceModule.service('AlertService', function() {
		var _message = {
			header : '',
			detailMessage : '',
			databaseMessage : '',
			success : false,
			warning : false,
			error : false,
			info : false
		};
		
		var _closable=true;

		var setDetailMessage = function(detailMessage) {
			_message.detailMessage = detailMessage;
		};
		var setDatabaseMessage = function(databaseMessage) {
			_message.databaseMessage = databaseMessage;
		};
		var setHeader = function(header) {
			_message.header = header;
		};
		var setSuccess = function(flag) {
			_message.success = flag;
		};
		var setWarning = function(flag) {
			_message.warning = flag;
		};
		var setError = function(flag) {
			_message.error = flag;
		};
		var setInfo = function(flag) {
			_message.info = flag;
		};

		var setMessage = function(message) {
			_message = {};
			_message = message;
			
		};
		var setClosable = function(closable) {
			_closable = closable;
		};
		
		var getDetailMessage = function() {
			return _message.detailMessage;
		};
		var getHeader = function() {
			return _message.header;
		};
		var getSuccess = function() {
			return _message.success;
		};
		var getWarning = function() {
			return _message.warning;
		};
		var getError = function() {
			return _message.error;
		};
		var getInfo = function() {
			return _message.info;
		};
		var getMessage = function() {
			return _message;
		};
		var getClosable = function() {
			return _closable;
		};
		

		return {
			setDetailMessage : setDetailMessage,
			getDetailMessage : getDetailMessage,
			setHeader : setHeader,
			getHeader : getHeader,
			setMessage : setMessage,
			setSuccess : setSuccess,
			setWarning : setWarning,
			setError : setError,
			setInfo : setInfo,
			getSuccess : getSuccess,
			getWarning : getWarning,
			getError : getError,
			getInfo : getInfo,
			getMessage : getMessage,
			setClosable : setClosable,
			getClosable : getClosable,
			setDatabaseMessage : setDatabaseMessage

		};

	});
});