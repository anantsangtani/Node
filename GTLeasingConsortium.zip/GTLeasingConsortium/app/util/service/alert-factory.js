define([ '../common-module' ], function(serviceModule) {
	serviceModule.service('AlertHandler', function() {

		   var service = {};
		   
		   var alertModels = {}; 
		   
		   service.defaultAlertModel = 'defaultAlert';
		   
		   service.init = function(_alertModel,alertObj) {
			   alertModels[_alertModel] = alertObj;
		   };
		   
		   service.getAlertModel = function(_alertModel) {
			   var nameToUse = _alertModel;
		       if (!_alertModel) {
		           nameToUse = service.defaultAlertModel;
		       }
		       return alertModels[nameToUse];
		   };
		   
		   return service;

	});
});