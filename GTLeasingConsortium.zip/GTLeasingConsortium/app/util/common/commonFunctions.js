define(['../common-module'], function (commons) {
    /*********************************************************************/
    /*    Defines functions which are common accross the application. ****/
    /*********************************************************************/
    commons.factory('commonFunctions', function () {
        let pageNumber = 1;
        let viewTransactionDetails = {};
        let isBackToTransaction = false;
        let setCurrentTransactionPageNumber = function (_pageNumber) {
            pageNumber = _pageNumber;
        };
        let getCurrentTransactionPageNumber = function () {
            return pageNumber;
        };
        let setViewTransactionTableDetails = function (obj) {
            viewTransactionDetails = obj;
        }
        let getViewTransactionTableDetails = function () {
            return viewTransactionDetails;
        }
        let setBackToTransactionFromCompare = function (_status) {
            isBackToTransaction = _status;
        }
        let getBackToTransactionFromCompare = function () {
            return isBackToTransaction;
        }
        return {
            "setCurrentTransactionPageNumber": setCurrentTransactionPageNumber,
            "getCurrentTransactionPageNumber": getCurrentTransactionPageNumber,
            "setViewTransactionTableDetails": setViewTransactionTableDetails,
            "getViewTransactionTableDetails": getViewTransactionTableDetails,
            "setBackToTransactionFromCompare": setBackToTransactionFromCompare,
            "getBackToTransactionFromCompare": getBackToTransactionFromCompare
        };
    });

});