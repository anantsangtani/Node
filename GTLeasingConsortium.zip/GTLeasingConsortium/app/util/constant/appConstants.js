define([ '../common-module' ], function(constants) {
	constants.constant('appConstants', function() {
    
		return {
            BASE_URL : "http://localhost/GTLeasingConsortium",
            JSON_URL : "./app/util/json/"
            
            
           
		};
	});

});

 