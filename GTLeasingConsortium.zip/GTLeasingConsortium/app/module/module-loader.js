define(['angular','app-module/home/module-loader','app-module/menu/module-loader','app-module/contractmanagement/module-loader'], function(angular) {
	return angular.module('app.module', ['app.home','app.menu','app.contractmanagement']);
});
