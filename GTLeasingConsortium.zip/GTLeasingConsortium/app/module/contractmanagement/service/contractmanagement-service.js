
define([ '../contractmanagement-module' ], function(serviceModule) {
    serviceModule.service('ContractManagementService', function($http,$q,Restangular,$rootScope, appConstants) {
    });
});
