define(['../contractmanagement-module'], function (controllerModule) {
    controllerModule.controller('ContractManagementController', function (Restangular,$http,$scope,$state, $rootScope, $location, $log, AlertService, HomeService,MenuService,ContractManagementService, $state, $mdDialog, dbConstants,$timeout,$stateParams) {
        var vm = this;
        $scope.showContractList=true;
        vm.users=[];
         vm.init=function()
       {
       	  
                $scope.columns = [
                {field:'RefNo',width:'10%',cellClass: 'noborder',cellTemplate:'<a style="color:#01579B;margin-left:45px;margin-top:5px;" ng-click="grid.appScope.viewrequest(row)">{{COL_FIELD}}</a>'},
                { field: 'ContractName',width:'12%',cellClass: 'noborder'},
                { field: 'ContractStartDate',width:'12%',cellClass: 'noborder'},
                { field: 'PeriodEndingOn',width:'12%',cellClass: 'noborder'},
                { field: 'Status',width:'15%',cellClass: 'noborder'},
                ];
            vm.users = [{RefNo:'Test-0917_001',ContractName : 'xyz',ContractStartDate:'03/02/2016',PeriodEndingOn:'03/02/2016',Status: 'Pending Review'}];
              vm.renderGrid();
              

       }
        
      
       vm.renderGrid = function(){
              vm.gridOptions = {
              enableSorting: true,
              columnDefs: $scope.columns,
              
              onRegisterApi: function(gridApi) {
                $scope.gridApi = gridApi;
                },
                      paginationPageSizes : ['5','10','20'],
                      useExternalPagination: false,
                      enableFiltering:false,
                      enableRowHashing:false,
                    
             };
             vm.gridOptions.data = vm.users;
          }
       
        vm.createContract = function(){
            $scope.showContractList=false;
        };
               
        
  });

});
                    