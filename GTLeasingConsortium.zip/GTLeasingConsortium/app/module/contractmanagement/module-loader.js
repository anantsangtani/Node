define([ 'app-module/contractmanagement/controller/contractmanagement-controller',
	'app-module/contractmanagement/service/contractmanagement-service'], function() {
});