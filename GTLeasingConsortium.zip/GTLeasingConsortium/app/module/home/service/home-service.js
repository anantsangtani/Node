
define([ '../home-module' ], function(serviceModule) {
    serviceModule.service('HomeService', function($http, Restangular, appConstants, $q) {
        let newCustomerModel = {username : '',password: ''};
        let getCustomerModel = function(){
           return angular.copy(newCustomerModel);
        };
        let saveUserDetails = function(_customerModel){
          newCustomerModel = _customerModel;
        };
        let getUser = function(loginModel){
            var defer = $q.defer();
            var usersResponse ="";
			/*URL = `userAuthentication.json`;
                Restangular.withConfig(function(RestangularConfigurer){
                    RestangularConfigurer.setBaseUrl(appConstants().JSON_URL);
                }).one(URL).post().then(function (response) {
				var usersResponse = response.plain();

				if (usersResponse) {
					defer.resolve(usersResponse);
					validUsers = usersResponse[0].users;
					var flag = false;

					if (!flag) {
						defer.reject();
					}
				}
			});
			return defer.promise;*/
            var response1 = {
                    "status": "SUCCESS",
                    "result": [{
                    "username": "alice.employee@lessor.com",
                    "role" : "lessor",
                    "emailID" : "alice.employee@lessor.com"
                    }]
            };
            var response2 = {
                    "status": "SUCCESS",
                    "result": [{
                    "username": "bob.employee@lessee.com",
                    "role" : "lessee",
                    "emailID" : "bob.employee@lessee.com"
                    }]
            };
            if(String(loginModel.username).indexOf("lessor")>-1){
                return response1;
            }
            if(String(loginModel.username).indexOf("lessee")>-1){
                return response2;
            } 
            return "";
		}
        return{
            getCustomerModel : getCustomerModel,
            saveUserDetails : saveUserDetails,
            getUser:getUser
        };
    });
});
