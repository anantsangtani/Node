define(['../home-module'], function (controllerModule) {
    controllerModule.controller('HomeController', function ($scope, $rootScope, $location, $log, AlertService, HomeService,MenuService,$state,md5) {
        var homeController = this;
        homeController.loginMessage = {};
        homeController.loginModel = {};
        homeController.init = function () {
              MenuService.setUserModel({});
         homeController.loginModel = {
                rememberMeFlag: 'N'
        };    
           
           
        };
        $('#carousel-example-generic').carousel({
            interval: 3000,
            cycle: true
            });    
        homeController.loginModel = HomeService.getCustomerModel();
        homeController.login = function () {
            
              var message = '';
            if (homeController.loginModel && !homeController.loginModel.username) {
                message = message + 'User Name is Mandatory,';
            }
            if (homeController.loginModel && !homeController.loginModel.password) {
                message = message + 'Password is  Mandatory,';
            }
            if (homeController.loginModel && homeController.loginModel.username && !isValidEmailAddress(homeController.loginModel.username)) {
                message = message + 'Email is Invalid,';
            }
            if (homeController.loginModel && !isValidpassword(homeController.loginModel.password)) {
                message = message + 'Password is  Invalid';
            }
            
            
            if (!message) {     
                //homeController.loginModel.password=md5.createHash(homeController.loginModel.password);
                var response = HomeService.getUser(homeController.loginModel);
                 var typeOfUser = '';
                    if(response.status == 'SUCCESS'){
                            homeController.currLoggedInUser = response.result[0];
                            window.sessionStorage.currLoggedInUser = JSON.stringify(homeController.currLoggedInUser);
                            window.sessionStorage.selectedIndex = 0;
                            MenuService.setUserModel(homeController.currLoggedInUser);
                            $state.go('contract-management');
                        
                    } else {
                        var message = {
                            header: 'Invalid User Id or Password! ',
                            detailMessage: message,
                            error: true
                        };
                        AlertService.setMessage(message);
                        homeController.loginMessage.showAlert();
                        
                    }
               
            } else {
                var message = {
                    header: 'Failure! ',
                    detailMessage: message,
                    error: true
                };
                AlertService.setMessage(message);
                homeController.loginMessage.showAlert();
                //homeController.loginMessageMobile.showAlert();
            }
        };
        function isValidEmailAddress(emailAddress) {
            var pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return pattern.test(emailAddress);
        };
        
        function isValidpassword(password) {
            var flag = false;
            if(homeController.loginModel.username.indexOf('@customer') !== -1){
                if(password == 'pinkfloyd1$'){
                flag = true;
                }
            }
            if(homeController.loginModel.username.indexOf('@bank') !== -1){
                if(password == 'godsmack1$'){
                flag = true;
                }
            }
            return true;
        };
        
    });
});
