define([ 'app-module/home/controller/home-controller',
	'app-module/home/service/home-service'], function() {
});
