define(['../menu-module', 'jquery.ui'], function (controllerModule) {
    controllerModule.controller('MenuController', function ($scope, $rootScope, MenuService, $location,$state,dbConstants,$stateParams,$window,commonFunctions) {
        var menuController = this;
        menuController.dbConstants = dbConstants().authentication;
        menuController.currTab = MenuService.getCurrentTab();
        menuController.init = function () {
           
            if(Object.keys(MenuService.getUserModel()).length > 0){
                menuController.loggedInUser = MenuService.getUserModel();
                $scope.loggedInUser = menuController.loggedInUser;
                $rootScope.loggedInUserName = $scope.loggedInUser.username;
                $rootScope.loggedInUserType = $scope.loggedInUser.userType;
                //$scope.authority = $scope.loggedInUser.name;
            }else if(window.sessionStorage.currLoggedInUser !== undefined && Object.keys(JSON.parse(window.sessionStorage.currLoggedInUser)).length>0){
                menuController.loggedInUser = JSON.parse(window.sessionStorage.currLoggedInUser);
                MenuService.setUserModel(menuController.loggedInUser); // incase needed
                $scope.loggedInUser = menuController.loggedInUser; 
                //$scope.authority = $scope.loggedInUser.name;
            }else{
                $state.go('home');
            }
            menuController.loggedInUser = MenuService.getUserModel();
            menuController.currTab = MenuService.getCurrentTab();
            var checkUrl = MenuService.getCurrentTab();
            /* set Current Menu Item */
            if(!checkUrl){
                 menuController.currentNavItem = 'contract-management';
            } else {
                menuController.currentNavItem = MenuService.getCurrentTab();
            }
            console.log('init',menuController.currentNavItem);
            /* set breadcrumb */
             switch($state.current.name){
               
               
                     
                case 'contract-management':
                        MenuService.resetHeaderBreadcrumb();
                        MenuService.setHeaderBreadcrumb('Contract List'); 
                        if(MenuService.getInvoiceRequestID() == ''){
                            MenuService.pushToHeaderBreadcrumb(MenuService.getInvoiceRequestID());
                        }else{
                            MenuService.pushToHeaderBreadcrumb('New Application');                            
                        }
                break;
                     
                     
                
                default:
                    MenuService.resetHeaderBreadcrumb();
                    /*(menuController.loggedInUser.userType == 'customer')? MenuService.setHeaderBreadcrumb('Dashboard') : MenuService.setHeaderBreadcrumb('pending-request') ;*/
                     MenuService.setHeaderBreadcrumb('contract-management')
            }
            menuController.getHeaderBreadcrumb = MenuService.getHeaderBreadcrumb();
        };
        menuController.redirectToPage = function(pageName){
            (window.sessionStorage.currLoggedInUser)? window.sessionStorage.removeItem("currLoggedInUser"):null;
            MenuService.setCurrentTab('');
            $state.go(pageName);
        }
        menuController.redirectToTargetPage = function (_href) {
            var href = MenuService.getCurrentTab();
            var obj = {};
            //set Request ID for credit request to BLANK
            MenuService.setInvoiceRequestID('');
            if(_href !== href){
                MenuService.setCurrentTab(_href);
                if (_href === 'contract-management') {
                    MenuService.setUserModel({});
                    setTimeout(function() {
                       
                        $state.go('contract-management');
                        
                    },200);
                }else if(_href === 'home' ){
                    $state.go('home');
                };
                
            }else{
                // $state.transitionTo($state.current,$stateParams , {
                //     reload : true,
                //     notify : true,
                //     inherit : false
                // });
            }
        };  
    });
});
