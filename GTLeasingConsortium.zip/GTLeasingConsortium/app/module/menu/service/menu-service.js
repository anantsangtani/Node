
define([ '../menu-module' ], function(serviceModule) {
	serviceModule.service('MenuService', function($http,Restangular,$rootScope) {
        var currencyPair = [];
		var submenu = '';
        var userModel = {};
        var currTab = '';
        var creditInvoiceReqID = '';
        $rootScope.breadcrumbArr = [];
        var setCurrencyPair = function(pair){
            currencyPair = pair;
        };
        var getCurrencyPair = function(){
            return currencyPair;
        };
        var setSubMenu = function(_submenu){
            submenu = _submenu;
        };
        var getSubMenu = function(){
            return submenu;
        };
        var setUserModel = function(_userModel){
          userModel = _userModel;
        };     
        var getUserModel = function(){
          return userModel;
        };
        var getTabs = function(_userId){
           /* return Restangular.all('menus').getList();*/
            //return menu;
        };
        var setCurrentTab = function(_currTab){
            currTab = _currTab;
        };
        var getCurrentTab = function(){
            return currTab;
        };
        var setInvoiceRequestID = function(id){
            creditInvoiceReqID = id;
        }
        var getInvoiceRequestID = function(){
            return creditInvoiceReqID;
        }
        var setHeaderBreadcrumb = function(breadcrumb){
            $rootScope.breadcrumbArr = [];
            $rootScope.breadcrumbArr[0] = breadcrumb;
        };
        var pushToHeaderBreadcrumb = function(breadcrumb){
            $rootScope.breadcrumbArr.push(breadcrumb);
        };
        var popHeaderbreadCrumb = function(){
            $rootScope.breadcrumbArr.pop();
        }
        var getHeaderBreadcrumb = function(){
            return $rootScope.breadcrumbArr;
        };
        var resetHeaderBreadcrumb = function(){
            $rootScope.breadcrumbArr = [];
        };
        return{
            setSubMenu  : setSubMenu,
            getSubMenu  : getSubMenu,
            getUserModel : getUserModel,
            setUserModel : setUserModel,
            getTabs : getTabs,
            setCurrentTab : setCurrentTab,
            getCurrentTab : getCurrentTab,
            setCurrencyPair: setCurrencyPair,
            getCurrencyPair: getCurrencyPair,
            setInvoiceRequestID: setInvoiceRequestID,
            getInvoiceRequestID: getInvoiceRequestID,
            setHeaderBreadcrumb: setHeaderBreadcrumb,
            pushToHeaderBreadcrumb: pushToHeaderBreadcrumb,
            popHeaderbreadCrumb: popHeaderbreadCrumb,
            getHeaderBreadcrumb: getHeaderBreadcrumb,
            resetHeaderBreadcrumb: resetHeaderBreadcrumb
        };
	});
});