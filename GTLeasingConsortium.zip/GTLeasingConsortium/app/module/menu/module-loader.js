define([ 'app-module/menu/controller/menu-controller',
         'app-module/menu/service/menu-service'
         ], function() {
});
