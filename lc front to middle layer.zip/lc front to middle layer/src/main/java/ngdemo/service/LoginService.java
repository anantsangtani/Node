package ngdemo.service;

import ngdemo.domain.Login;

public class LoginService {
	public Login getDefaultUser() {
		return null;
	}

	public Login fetchUser(Login user) {
		System.out.println(user.getUsername());
		Login demouser1 = new Login();
		Login demouser2 = new Login();
		Login demouser3 = new Login();

		demouser1.setUsername("trafigura");
		demouser1.setPassword("t1234");

		demouser2.setUsername("counterparty");
		demouser2.setPassword("c1234");

		demouser3.setUsername("issuingbank");
		demouser3.setPassword("b1234");

		if (user.getUsername().equals(demouser1.getUsername())
				&& user.getPassword().equals(demouser1.getPassword())) {

			user.setAuthenticated(true);

		} else if (user.getUsername().equals(demouser2.getUsername())
				&& user.getPassword().equals(demouser2.getPassword())) {
			user.setAuthenticated(true);

		} else if (user.getUsername().equals(demouser3.getUsername())
				&& user.getPassword().equals(demouser3.getPassword())) {
			user.setAuthenticated(true);
		}

		else {
			user.setAuthenticated(false);
		}
		return user;
	}
}
