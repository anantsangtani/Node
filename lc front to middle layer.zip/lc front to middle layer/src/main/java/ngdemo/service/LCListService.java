package ngdemo.service;

import java.util.ArrayList;

import ngdemo.domain.LcList;

public class LCListService {

	public LcList getList() {
		LcList lcobj1= new LcList();
		LcList lcobj2= new LcList();
		LcList lcobj3= new LcList();
		
		ArrayList<LcList> list = new ArrayList<LcList>();
		
		lcobj1.setLcId("1");
		lcobj1.setLcName("First Lc");
		lcobj1.setLcStatus("Active");
		
		lcobj2.setLcId("2");
		lcobj2.setLcName("Second Lc");
		lcobj2.setLcStatus("Pending");
		
		lcobj3.setLcId("3");
		lcobj3.setLcName("Third Lc");
		lcobj3.setLcStatus("Completed");
		
		list.add(lcobj1);
		list.add(lcobj2);
		list.add(lcobj3);
		
		lcobj1.setList(list);
		return lcobj1;
	}

}
