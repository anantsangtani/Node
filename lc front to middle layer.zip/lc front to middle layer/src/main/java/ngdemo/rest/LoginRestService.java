package ngdemo.rest;

import ngdemo.domain.Login;
import ngdemo.service.LoginService;


import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("/users")
public class LoginRestService {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Login getDefaultUserInJSON() {
    	LoginService loginService = new LoginService();
        return loginService.getDefaultUser();
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Login create(Login user) {
	 LoginService loginService = new LoginService();
    return loginService.fetchUser(user);
}
}
