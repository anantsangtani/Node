package ngdemo.rest;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import ngdemo.domain.LcList;
import ngdemo.service.LCListService;

@Path("/lc")
public class LcListRestService {

	 @GET
	    @Produces(MediaType.APPLICATION_JSON)
	    public LcList getDefaultUserInJSON() {
	    	LCListService lcService = new LCListService();
	        return lcService.getList();
	    }
	
	
	
}
