package ngdemo.domain;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
// from http://www.vogella.com/articles/REST/
// JAX-RS supports an automatic mapping from JAXB annotated class to XML and JSON
public class LcList {

    private String lcId;
    private String lcName;
    private String lcStatus;
    ArrayList<LcList> list;
    
	public ArrayList<LcList> getList() {
		return list;
	}
	public void setList(ArrayList<LcList> list) {
		this.list = list;
	}
	public LcList() {
		super();
	}
	public LcList(String lcId, String lcName, String lcStatus) {
		super();
		this.lcId = lcId;
		this.lcName = lcName;
		this.lcStatus = lcStatus;
	}
	@Override
	public String toString() {
		return "LcList [lcId=" + lcId + ", lcName=" + lcName + ", lcStatus="
				+ lcStatus + "]";
	}
	public String getLcId() {
		return lcId;
	}
	public void setLcId(String lcId) {
		this.lcId = lcId;
	}
	public String getLcName() {
		return lcName;
	}
	public void setLcName(String lcName) {
		this.lcName = lcName;
	}
	public String getLcStatus() {
		return lcStatus;
	}
	public void setLcStatus(String lcStatus) {
		this.lcStatus = lcStatus;
	}
	
    
    

}
