angular
        .module('app')
        .controller('issuingBankController', issuingBankController);
