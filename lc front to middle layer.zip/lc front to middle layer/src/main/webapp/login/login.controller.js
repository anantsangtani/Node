﻿(function() {
	'use strict';

	angular.module('app').controller('LoginController', LoginController);

	LoginController.$inject = [ '$location', 'AuthenticationService',
			'FlashService' ];
	function LoginController($location, AuthenticationService, FlashService) {
		var vm = this;
		vm.login = login;
		function login() {
			console.log(vm);
			AuthenticationService.create(vm, function(AuthenticationService) {

				console.log(AuthenticationService.authenticated);
				if (AuthenticationService.authenticated
						&& AuthenticationService.username == "trafigura") {
					console.log("inside tra");
					$location.path('/');
					console.log($location.path());
					

				} else if (AuthenticationService.authenticated
						&& AuthenticationService.username == "counterparty") {
					$location.path('/counterhome');
					console.log($location.path());
				} else if (AuthenticationService.authenticated
						&& AuthenticationService.username == "issuingbank") {
					$location.path('/bankhome');
					console.log($location.path());
				} else {
					FlashService.Error("Please check Username and Password");
				}

			});
		}
		
	}

})();
