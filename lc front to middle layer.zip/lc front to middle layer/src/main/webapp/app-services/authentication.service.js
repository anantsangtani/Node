﻿(function() {
	'use strict';

	angular.module('app').factory('AuthenticationService',
			AuthenticationService);

	AuthenticationService.$inject = [ '$http', '$cookies', '$resource',
			'$rootScope', '$timeout', 'UserService' ];
	function AuthenticationService($http, $cookies, $resource, $rootScope,
			$timeout, UserService) {
		return $resource('/ngdemo/rest/users', {}, {
			create : {
				method : 'POST',
				param : {},
				isArray : false
			}
		})
		return $resource('/ngdemo/rest/lc', {}, {

			lclist : {
				method : 'GET',
				param : {},
				isArray : true
			}
		})

	}
	
})();
