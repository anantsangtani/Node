(function() {
	'use strict';

	angular.module('app').factory('HomeService',
			HomeService);

	HomeService.$inject = [ '$http', '$cookies', '$resource',
			'$rootScope', '$timeout', 'UserService' ];
	function HomeService($http, $cookies, $resource, $rootScope,
			$timeout, UserService) {
		return $resource('/ngdemo/rest/lc', {}, {

			lclist : {
				method : 'GET',
				param : {},
				isArray : true
			}
		})

	}
	
})();
