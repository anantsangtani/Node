﻿(function() {
	'use strict';

	angular.module('app').controller('HomeController', HomeController);

	HomeController.$inject = [ '$location', 'HomeService',
			'FlashService' ];
	function HomeController($location, HomeService, FlashService) {
		var vm = this;
		
		HomeService.lclist({}, function(HomeService) {
			console.log("list is "+HomeService);
		})
}})();
